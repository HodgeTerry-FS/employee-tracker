class Employee{
    constructor(name,age){
        this.name = name;
        this.age = age;
        this.annualSalary = 0;
    }
}

class Manager extends Employee{
    constructor(name,age,payRate){
        super(name,age);
        this.payRate = payRate;
        this.type = "Manager"
    }
    calculatePay(){
        this.annualSalary = ((this.payRate * 40)*52)-1000;
    }
}

class PartTime extends Employee{
    constructor(name,age,payRate){
        super(name,age);
        this.payRate = payRate;
        this.type = "Part time"
    
    }
     calculatePay(){
        this.annualSalary = ((this.payRate * 40)*52);
    }
}

class Hr{
    constructor(){
        this.displayMenu();
        

    }
    displayMenu(){
        let pick = Number(prompt("Main Menu\n1.Add Employee\n2.Remove Employee\n3.Edit Employee\n4.Display Emploee\n\n\nEnter selection" )); 
        switch(pick){
            case 1: this.addEmployee();
            break;
            case 2: this.removeEmployee();
            break;
            case 3: this.editEmployee();
            break;
            case 4: this.displayEmployee();
            break;
        }


    }
    addEmployee(){
        let userEmployee = String(prompt("Add Employee Name,age,hours worked,pay rate [you MUST seperate each by a comma]"));

        let userArray = userEmployee.split(",");
        let employee4 = new PartTime(userArray);
        
         alert("User created");
         console.log("Terry's Daddy DayCare");
         console.log("ID\tName\tAge\tSalary\tHrs\tPay\tType");
         console.log(employee4);
         //if (userArray[2] <=40){
            
        
                //let userArray = new Manager(userArray);
                 // else userArray = new PartTime(userArray);{
                
       

    }
    removeEmployee(){

        
        console.log("Terry's Daddy DayCare");
        console.log("ID\tName\tAge\tSalary\tHrs\tPay\tType");
        let employee1 = new Manager("Tom",45,40,25);
        let employee2 = new PartTime("Dick",30,10,8);
        let employee3 = new PartTime("Harry",32,10,1);
        employee1.calculatePay();
        employee2.calculatePay();
        employee3.calculatePay();
        const employees = [ employee1,employee2,employee3]  ;
        console.table(employees);
        let removeNumber = Number(prompt("Please type in the Name or ID Number of the employee that you want to remove." )); 
        if (removeNumber == 0) {
            employees.slice(0);
            if (removeNumber == 1){
                employees.slice(1);
            } if(removeNumber == 2){
           employees.slice(2);}
        }
        console.table(employees);


    }
    editEmployee(){

    }
    displayEmployee(){
        console.clear();
        console.log("Terry's Daddy DayCare");
        console.log("ID\tName\tAge\tSalary\tHrs\tPay\tType");
        let employee1 = new Manager("Tom",45,40,25);
        let employee2 = new PartTime("Dick",30,10,8);
        let employee3 = new PartTime("Harry",32,10,1);
        employee1.calculatePay();
        employee2.calculatePay();
        employee3.calculatePay();
        const employees = [ employee1,employee2,employee3]  ;
        console.table(employees);
        


    }
}


(e=>{
    const hr = new Hr();
})();